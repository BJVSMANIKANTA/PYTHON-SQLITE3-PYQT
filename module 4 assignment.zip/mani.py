class book:
    def __init__(self,a='mankind',b='manijvs',c='argraphics',d=400,e=500):
        self.title=a
        self.author=b
        self.publisher=c
        self.price=d
        self.quantity=e
        royality=0
    def get_title(self):
        return self._title
    def set_title(self):
        self.title=a
        return
    def get_author(self):
        return self.author
    def set_author(self):
        self.author=b
        return
    def get_publisher(self):
        return self.publisher
    def set_publisher(self):
        self.publisher=c
        return
    def get_price(self):
        return self.price
    def set_price(self):
        self.price=d
        return
    def get_quantity(self):
        return self.quantity
    def set_quantity(self):
        self.quantity=e
        return
    def royality(self):
        if self.quantity<=500:
            royality=.1*self.price*self.quantity
        elif self.quantity>500 and self.quantity<=1500:
            royality=.125*self.price*(self.quantity-500)+.1*self.price*500
        elif self.quantity>1500:
            royality=.1*self.price*500+.125*self.price*1000+.15*self.price*(self.quantity-1500)
        return royality

class ebook(book):
    def __init__(self,aa='pdf'):
        self._format=aa
    def get_format(self):
        return self.format
    def set_format(self,b):
        self.format=b
        return
    def royality(self):
        if self.quantity<=500:
            royality=.1*self.price*self.quantity
        elif self.quantity>500 and self.quantity<=1500:
            royality=.125*self.price*(self.quantity-500)+.1*self.price*500
        elif self.quantity>1000:
            royality=.1*self.price*500+.125*self.price*1000+.15*self.price*(self.quantity-1500)
        royality=royality-(.12*royality)
        return royality
a=input(" Enter the title of the book ")
b=input(" Enter the author ofthe book ")
c=input(" Enter the publisher of book ")
d=int(input(" Enter the price of the book "))
e=int(input(" Enter the total number of books sold "))
f=int(input(" Enter 1 for normal book else  enter 2 for e-book "))
y=ebook()
if f==1:
    x = book(a, b, c, d, e)
    z=x.royality()
    print(" Title is {} \n Publisher is {} \n Author is {} \n Price was {} \n Total sold {} \n Royalty is {} \n".format(x.title,x.publisher,x.author,x.price,x.quantity,z))
if f==2:
    print("b")
    g=input("Enter the ebook format type")
    z=y.royality()
    y.set_format(g)
    print(" Title is {} \n Publisher is {} \n Author is {} \n Price was {} \n Total sold {} \n Format is {} \n Royalty is {} \n".format(y.title,y.publisher,y.author,y.price,y.quantity,y.format,z))
    
