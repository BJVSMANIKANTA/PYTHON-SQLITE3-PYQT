import points
p1={'name':'viratkohli','role':'bat','runs':112,'four':10,'six':0,'balls':119,'field':0}
p2={'name':'du plesis','role':'bat','runs':120,'four':11,'six':2,'balls':112,'field':0}
p3={'name':'Bhuwaneswarkumar','role':'bowl','wickets':1,'overs':10,'runs':71,'field':1}
p4={'name':'yuzvendra chahal','role':'bowl','wickets':2,'overs':10,'runs':45,'field':0}
p5={'name':'Bhuwaneswarkumar','role':'bowl','wickets':3,'overs':10,'runs':34,'field':0}

players=[p1,p2,p3,p4,p5]
scores = {}

for i in players:
    if i['role'] == 'bat':
        score = points.bat(i)
        scores[i['name']] = score
        print("'name':{},'batscore':{}".format(i['name'],score))
    else:
        score = points.bowl(i)
        scores[i['name']] = score
        print("'name':{},'bowlscore':{}".format(i['name'],score))

max_scorer = max(scores,key=scores.get)

print("The maximum scorer is {} with score {}".format(max_scorer,max(scores.values())))


