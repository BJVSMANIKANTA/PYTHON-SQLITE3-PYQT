def bat(i):
    runs=i['runs']
    strikerate = runs / i['balls']
    points = runs // 2
    if runs > 49 and runs < 100:
        points = points + 5
    elif runs >= 100:
        points = points + 10

    if strikerate > 79 and runs <= 100:
        points = points + 2
    elif strikerate > 100:
        points = points + 4

    while i['four'] > 0:
        points = points + i['four']

    while i['six'] > 0:
        points = points + (i['six'] * 2)

    while i['field'] > 0:
        points = points + i['field'] * 10

    return {'name': i['name'], 'batscore': points}

def ball(i):
    wickets=i['wickets']
    economyrate = i['runs'] / i['overs']
    points = wickets * 10
    if wickets > 2 and i['runs'] < 5:
        points = points + 5
    elif wickets >= 5:
        points = points + 10

    if economyrate > 3.4 and i['runs'] <= 4.5:
        points = points + 4
    elif economyrate > 1.9 and i['runs'] <= 3.5:
        points = points + 7
    elif economyrate < 2:
        points = points + 10

    while i['field'] > 0:
        points = points + i['field'] * 10

    return {'name': i['name'], 'batscore': points}