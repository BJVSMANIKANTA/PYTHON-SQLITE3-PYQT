import sqlite3
myclg = sqlite3.connect("library.db")
curclg = myclg.cursor()
totalprice=0
while True:
    NAME = input("BOOK TITLE: ")
    sql = "SELECT * FROM LIBRARY WHERE BTITLE = ?;"
    curclg.execute(sql, (NAME,))
    record = curclg.fetchone()
    print(record)
    n=int(input("No. of copies: "))
    totalprice = totalprice+record[3]*n
    addbook=input("Add more books? Y/N ")
    if addbook == 'N':
        break
print("Total Cost {}".format(totalprice))
n=input("enter to exit")
myclg.close()