import sqlite3
myclg = sqlite3.connect("library.db")
curclg = myclg.cursor()
#ycurclg.execute('''CREATE TABLE LIBRARY(BOOK ID,BTITLE TEXT PRIMARYKEY,BAUTHOR,BPRICE NOT NULL);''')
while True:
    x=input("do you want to enter the data y/n :")
    if x == 'y':
        a=int(input("enter book id: "))
        b=input("enter book title: ")
        c=input("enter book author: ")
        d=int(input("enter book price: "))
        curclg.execute('''INSERT INTO LIBRARY (
                        BOOKID,
                       BTITLE,
                       BAUTHOR,
                        BPRICE
                    )VALUES(?,?,?,?);''',(a,b,c,d))
    else:
        break

myclg.commit()
